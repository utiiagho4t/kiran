import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import Navigation from "@/components/Navigation";
import { ArrowLeft, ArrowRight, Clock, CheckCircle } from "lucide-react";

const QuizPlayer = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);

  const mockQuiz = {
    title: "JavaScript Fundamentals",
    questions: [
      {
        id: 1,
        text: "What is the correct way to declare a variable in JavaScript?",
        options: [
          "var myVariable = 'hello';",
          "variable myVariable = 'hello';",
          "v myVariable = 'hello';",
          "declare myVariable = 'hello';"
        ],
        correct: 0,
        explanation: "The 'var' keyword is used to declare variables in JavaScript, though 'let' and 'const' are preferred in modern JavaScript."
      },
      {
        id: 2,
        text: "Which of the following is NOT a JavaScript data type?",
        options: [
          "Number",
          "String",
          "Float",
          "Boolean"
        ],
        correct: 2,
        explanation: "JavaScript has Number, String, Boolean, Object, Undefined, and Null as primitive data types. 'Float' is not a distinct type."
      },
      // Mock additional questions for demo
      ...Array.from({ length: 8 }, (_, i) => ({
        id: i + 3,
        text: `Sample question ${i + 3} about JavaScript concepts?`,
        options: [
          `Option A for question ${i + 3}`,
          `Option B for question ${i + 3}`,
          `Option C for question ${i + 3}`,
          `Option D for question ${i + 3}`
        ],
        correct: i % 4,
        explanation: `This is the explanation for question ${i + 3}.`
      }))
    ]
  };

  const totalQuestions = mockQuiz.questions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleAnswerSelect = (value: string) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [currentQuestion]: value
    }));
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    setShowResults(true);
  };

  const calculateScore = () => {
    let correct = 0;
    mockQuiz.questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correct.toString()) {
        correct++;
      }
    });
    return Math.round((correct / totalQuestions) * 100);
  };

  if (showResults) {
    const score = calculateScore();
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-gradient-success rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-2xl">Quiz Completed!</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div>
                <div className="text-4xl font-bold text-primary mb-2">{score}%</div>
                <p className="text-muted-foreground">
                  You answered {Object.keys(selectedAnswers).length} out of {totalQuestions} questions correctly
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Question Review</h3>
                {mockQuiz.questions.slice(0, 2).map((question, index) => (
                  <div key={question.id} className="text-left p-4 border rounded-lg">
                    <p className="font-medium mb-2">Q{index + 1}: {question.text}</p>
                    <p className="text-sm text-muted-foreground mb-2">
                      Your answer: {question.options[parseInt(selectedAnswers[index]) || 0]}
                    </p>
                    <p className="text-sm text-success">
                      Correct answer: {question.options[question.correct]}
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      {question.explanation}
                    </p>
                  </div>
                ))}
                {totalQuestions > 2 && (
                  <p className="text-sm text-muted-foreground">
                    ... and {totalQuestions - 2} more questions reviewed
                  </p>
                )}
              </div>

              <div className="flex gap-4 justify-center">
                <Button variant="default">
                  Retake Quiz
                </Button>
                <Button variant="outline">
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const question = mockQuiz.questions[currentQuestion];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quiz Header */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">{mockQuiz.title}</h1>
            <div className="flex items-center space-x-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span className="text-sm">15:30</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Question {currentQuestion + 1} of {totalQuestions}</span>
              <span>{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </div>

        {/* Question Card */}
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-lg leading-relaxed">
              {question.text}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <RadioGroup
              value={selectedAnswers[currentQuestion] || ""}
              onValueChange={handleAnswerSelect}
              className="space-y-3"
            >
              {question.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>

            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>

              {currentQuestion === totalQuestions - 1 ? (
                <Button
                  onClick={handleSubmit}
                  disabled={!selectedAnswers[currentQuestion]}
                  variant="success"
                >
                  Submit Quiz
                  <CheckCircle className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleNext}
                  disabled={!selectedAnswers[currentQuestion]}
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Question Navigator */}
        <div className="max-w-2xl mx-auto mt-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-2">
                {mockQuiz.questions.map((_, index) => (
                  <Button
                    key={index}
                    variant={
                      index === currentQuestion
                        ? "default"
                        : selectedAnswers[index] !== undefined
                        ? "success"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => setCurrentQuestion(index)}
                    className="w-10 h-10 p-0"
                  >
                    {index + 1}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default QuizPlayer;