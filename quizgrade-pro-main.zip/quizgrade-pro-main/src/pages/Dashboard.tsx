import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/Navigation";
import { 
  BookOpen, 
  Plus, 
  Play, 
  Trophy, 
  Users, 
  BarChart3, 
  Clock,
  CheckCircle,
  XCircle
} from "lucide-react";

const Dashboard = () => {
  const [userRole] = useState<"user" | "quiz-manager" | "admin">("user");

  const mockQuizzes = [
    { id: 1, title: "JavaScript Fundamentals", questions: 10, completed: true, score: 85 },
    { id: 2, title: "React Components", questions: 10, completed: true, score: 92 },
    { id: 3, title: "TypeScript Basics", questions: 10, completed: false, score: null },
    { id: 4, title: "CSS Grid & Flexbox", questions: 10, completed: false, score: null },
  ];

  const mockTopics = [
    { id: 1, title: "Advanced JavaScript", questions: 10, status: "published", attempts: 245 },
    { id: 2, title: "Node.js Essentials", questions: 8, status: "draft", attempts: 0 },
    { id: 3, title: "Database Design", questions: 10, status: "published", attempts: 156 },
  ];

  const renderStudentDashboard = () => (
    <div className="space-y-8">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Trophy className="h-8 w-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">88.5%</p>
                <p className="text-sm text-muted-foreground">Avg Score</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-8 w-8 text-success" />
              <div>
                <p className="text-2xl font-bold">12</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-8 w-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">3</p>
                <p className="text-sm text-muted-foreground">In Progress</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-8 w-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">24h</p>
                <p className="text-sm text-muted-foreground">Study Time</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Available Quizzes */}
      <Card>
        <CardHeader>
          <CardTitle>Available Quizzes</CardTitle>
          <CardDescription>Continue your learning journey</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {mockQuizzes.map((quiz) => (
              <Card key={quiz.id} className="border border-border/50">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-semibold">{quiz.title}</h3>
                    <Badge variant={quiz.completed ? "default" : "secondary"}>
                      {quiz.completed ? "Completed" : "Available"}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {quiz.questions} questions
                  </p>
                  {quiz.completed && quiz.score && (
                    <div className="flex items-center space-x-2 mb-4">
                      <Trophy className="h-4 w-4 text-accent" />
                      <span className="text-sm font-medium">Score: {quiz.score}%</span>
                    </div>
                  )}
                  <Button 
                    variant={quiz.completed ? "outline" : "default"} 
                    size="sm" 
                    className="w-full"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {quiz.completed ? "Retake Quiz" : "Start Quiz"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderQuizManagerDashboard = () => (
    <div className="space-y-8">
      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Manage your quiz topics and questions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button variant="default">
              <Plus className="w-4 h-4 mr-2" />
              Create New Topic
            </Button>
            <Button variant="outline">
              <BookOpen className="w-4 h-4 mr-2" />
              Manage Questions
            </Button>
            <Button variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              View Analytics
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Your Topics */}
      <Card>
        <CardHeader>
          <CardTitle>Your Topics</CardTitle>
          <CardDescription>Manage and monitor your quiz topics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockTopics.map((topic) => (
              <div key={topic.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <h3 className="font-semibold">{topic.title}</h3>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span>{topic.questions} questions</span>
                    <span>{topic.attempts} attempts</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={topic.status === "published" ? "default" : "secondary"}>
                    {topic.status}
                  </Badge>
                  <Button variant="outline" size="sm">Edit</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderAdminDashboard = () => (
    <div className="space-y-8">
      {/* System Overview */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">1,247</p>
                <p className="text-sm text-muted-foreground">Total Users</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-success" />
              <div>
                <p className="text-2xl font-bold">89</p>
                <p className="text-sm text-muted-foreground">Active Topics</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-8 w-8 text-accent" />
              <div>
                <p className="text-2xl font-bold">12,456</p>
                <p className="text-sm text-muted-foreground">Quiz Attempts</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Admin Actions */}
      <Card>
        <CardHeader>
          <CardTitle>System Management</CardTitle>
          <CardDescription>Administrative tools and controls</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <Button variant="default" className="h-auto p-6 flex-col space-y-2">
              <Users className="h-8 w-8" />
              <span>Manage Users</span>
            </Button>
            <Button variant="outline" className="h-auto p-6 flex-col space-y-2">
              <BookOpen className="h-8 w-8" />
              <span>Topic Overview</span>
            </Button>
            <Button variant="outline" className="h-auto p-6 flex-col space-y-2">
              <BarChart3 className="h-8 w-8" />
              <span>System Analytics</span>
            </Button>
            <Button variant="outline" className="h-auto p-6 flex-col space-y-2">
              <Trophy className="h-8 w-8" />
              <span>Role Management</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {userRole === "user" && "Student Dashboard"}
            {userRole === "quiz-manager" && "Quiz Manager Dashboard"}
            {userRole === "admin" && "Admin Dashboard"}
          </h1>
          <p className="text-muted-foreground">
            {userRole === "user" && "Track your progress and continue learning"}
            {userRole === "quiz-manager" && "Create and manage your quiz topics"}
            {userRole === "admin" && "Oversee the entire QuizGrad system"}
          </p>
        </div>

        {userRole === "user" && renderStudentDashboard()}
        {userRole === "quiz-manager" && renderQuizManagerDashboard()}
        {userRole === "admin" && renderAdminDashboard()}
      </div>
    </div>
  );
};

export default Dashboard;