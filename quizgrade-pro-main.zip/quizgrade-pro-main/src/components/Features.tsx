import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Trophy, Users, Clock, BarChart3, Shield } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: Brain,
      title: "Smart Quiz Creation",
      description: "Create engaging MCQ quizzes with exactly 10 questions. Our intelligent system ensures optimal learning outcomes."
    },
    {
      icon: Trophy,
      title: "Auto-Grading System",
      description: "Instant feedback with comprehensive scoring. Track progress and identify areas for improvement automatically."
    },
    {
      icon: Users,
      title: "Role-Based Access",
      description: "Three distinct roles - Students, Quiz Managers, and Admins - each with tailored functionality and permissions."
    },
    {
      icon: Clock,
      title: "Real-Time Results",
      description: "Get immediate quiz results with detailed explanations. Monitor performance trends over time."
    },
    {
      icon: BarChart3,
      title: "Analytics Dashboard",
      description: "Comprehensive insights into quiz performance, user engagement, and learning progress."
    },
    {
      icon: Shield,
      title: "Secure & Reliable",
      description: "Enterprise-grade security with role-based authentication and data protection protocols."
    }
  ];

  return (
    <section className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold">
            Why Choose <span className="text-primary">QuizGrad</span>?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the features that make QuizGrad the perfect platform for modern education
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="h-full hover:shadow-medium transition-all duration-300 border-0 bg-card/60 backdrop-blur">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;